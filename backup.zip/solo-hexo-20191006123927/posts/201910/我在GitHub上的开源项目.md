title: 我在 GitHub 上的开源项目
date: '2019-10-06 12:29:27'
updated: '2019-10-06 12:29:27'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [yunque](https://github.com/hujiaqi1995/yunque) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/hujiaqi1995/yunque/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/hujiaqi1995/yunque/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/hujiaqi1995/yunque/network/members "分叉数")</span>





---

### 2. [tl](https://github.com/DT0814/tl) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/DT0814/tl/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/DT0814/tl/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/DT0814/tl/network/members "分叉数")</span>





---

### 3. [qrcode-server](https://github.com/hujiaqi1995/qrcode-server) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/hujiaqi1995/qrcode-server/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/hujiaqi1995/qrcode-server/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/hujiaqi1995/qrcode-server/network/members "分叉数")</span>





---

### 4. [demo](https://github.com/hujiaqi1995/demo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/hujiaqi1995/demo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/hujiaqi1995/demo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/hujiaqi1995/demo/network/members "分叉数")</span>





---

### 5. [hotel-server](https://github.com/hujiaqi1995/hotel-server) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/hujiaqi1995/hotel-server/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/hujiaqi1995/hotel-server/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/hujiaqi1995/hotel-server/network/members "分叉数")</span>





---

### 6. [hotel-web](https://github.com/hujiaqi1995/hotel-web) <kbd title="主要编程语言">Vue</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/hujiaqi1995/hotel-web/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/hujiaqi1995/hotel-web/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/hujiaqi1995/hotel-web/network/members "分叉数")</span>





---

### 7. [webflex-demo](https://github.com/hujiaqi1995/webflex-demo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/hujiaqi1995/webflex-demo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/hujiaqi1995/webflex-demo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/hujiaqi1995/webflex-demo/network/members "分叉数")</span>





---

### 8. [digital_asset](https://github.com/hujiaqi1995/digital_asset) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/hujiaqi1995/digital_asset/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/hujiaqi1995/digital_asset/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/hujiaqi1995/digital_asset/network/members "分叉数")</span>





---

### 9. [tl](https://github.com/hujiaqi1995/tl) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/hujiaqi1995/tl/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/hujiaqi1995/tl/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/hujiaqi1995/tl/network/members "分叉数")</span>





---

### 10. [qrcode](https://github.com/hujiaqi1995/qrcode) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/hujiaqi1995/qrcode/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/hujiaqi1995/qrcode/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/hujiaqi1995/qrcode/network/members "分叉数")</span>



